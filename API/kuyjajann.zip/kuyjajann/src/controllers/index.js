//const karyawan = require('./controller-karyawan');
const user = require('./controller-user');
const toko = require('./controller-toko');
const kurir = require('./controller-kurir');
const dagangan = require('./controller-dagangan');
const wishlist = require('./controller-wishlist');
const orders = require('./controller-orders');


module.exports ={
	user,toko,kurir,dagangan,wishlist,orders
};